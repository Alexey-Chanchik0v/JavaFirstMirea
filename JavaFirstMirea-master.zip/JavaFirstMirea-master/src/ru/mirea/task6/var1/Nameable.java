package ru.mirea.task6.var1;

public interface Nameable {
    String getName();
}
