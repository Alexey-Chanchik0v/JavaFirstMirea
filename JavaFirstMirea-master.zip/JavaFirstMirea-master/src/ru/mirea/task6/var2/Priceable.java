package ru.mirea.task6.var2;

public interface Priceable {
    int getPrice();
}
