package ru.mirea.task26;

public interface PayStrategy {
    void pay();
}
