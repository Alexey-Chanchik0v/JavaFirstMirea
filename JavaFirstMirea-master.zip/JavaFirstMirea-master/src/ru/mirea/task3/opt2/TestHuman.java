package ru.mirea.task3.opt2;

public class TestHuman {
    public static void main(String[]args)
    {
        Human human=new Human("Олег");
        System.out.print(human.getStatistic());
    }
}
