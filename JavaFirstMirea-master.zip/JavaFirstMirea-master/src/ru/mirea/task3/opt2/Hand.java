package ru.mirea.task3.opt2;

public class Hand {
    private int health;
    public void setHealth(int health) {
        this.health = health;
    }

    public int getHealth(){return health;}
}
