package ru.mirea.task7.Task;

public interface Movable {
    void moveUp();
    void moveDown();
    void moveRight();
    void moveLeft();
}
