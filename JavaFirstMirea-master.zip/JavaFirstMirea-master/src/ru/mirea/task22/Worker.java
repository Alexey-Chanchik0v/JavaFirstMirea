package ru.mirea.task22;

public class Worker extends User{
    public String getType() {
        return "Worker";
    }
}
