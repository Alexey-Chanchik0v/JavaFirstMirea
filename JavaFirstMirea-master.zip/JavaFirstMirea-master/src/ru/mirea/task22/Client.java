package ru.mirea.task22;

public class Client extends User{
    public String getType() {
        return "Client";
    }
}
