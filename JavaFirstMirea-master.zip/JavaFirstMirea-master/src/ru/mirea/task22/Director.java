package ru.mirea.task22;

public class Director extends User{
    public String getType() {
        return "Director";
    }
}
