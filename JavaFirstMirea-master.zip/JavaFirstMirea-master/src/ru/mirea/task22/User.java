package ru.mirea.task22;

public class User {
    String name,login,password;

    public User() {
    }
    public String getType() {
        return "User";
    }
}

