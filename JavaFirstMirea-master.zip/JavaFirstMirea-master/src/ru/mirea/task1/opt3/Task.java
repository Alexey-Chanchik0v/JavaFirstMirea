package ru.mirea.task1.opt3;

public class Task {
    public static void main(String []args)
    {
        for (int i=1;i<11;i++)
        {
            double c=1/(double)i;
            System.out.print(String.format("%.3f",c)+" ");
        }
    }
}
