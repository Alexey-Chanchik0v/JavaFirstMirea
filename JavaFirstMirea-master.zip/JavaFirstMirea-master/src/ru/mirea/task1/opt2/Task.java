package ru.mirea.task1.opt2;

public class Task {
    public static void main(String []args)
    {
        for (String arg : args) {
            System.out.print(arg + " ");
        }
    }
}
