package ru.mirea.task25;

public class LongPeriod extends OptionPercent{
    public LongPeriod(Percent percent)
    {
        super(percent,3);
    }
}
