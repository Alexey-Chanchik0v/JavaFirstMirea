package ru.mirea.task25;

public interface Percent {
    int getPercent();
}
