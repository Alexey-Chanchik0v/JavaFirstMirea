package ru.mirea.task25;

public class BigSum extends OptionPercent{
    public BigSum(Percent percent)
    {
        super(percent,2);
    }
}
