package ru.mirea.task25;

public class VipStatus extends OptionPercent {
    public VipStatus(Percent percent)
    {
        super(percent,8);
    }
}
